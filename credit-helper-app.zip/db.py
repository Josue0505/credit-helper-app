import sqlite3

def init_db():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE,
            password TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS pagos (
            id INTEGER PRIMARY KEY,
            username TEXT,
            amount REAL
        )
    ''')
    conn.commit()
    conn.close()

def register_user(username, password):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def login_user(username, password):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
    result = c.fetchone()
    conn.close()
    return result is not None

def save_payment(username, amount):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("INSERT INTO pagos (username, amount) VALUES (?, ?)", (username, amount))
    conn.commit()
    conn.close()

def get_user_payments(username):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("SELECT amount FROM pagos WHERE username=?", (username,))
    data = c.fetchall()
    conn.close()
    return [d[0] for d in data]
