import streamlit as st
from db import init_db, register_user, login_user, save_payment, get_user_payments

init_db()

st.set_page_config(page_title="App de Crédito", layout="centered")

if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.username = ""

def login_section():
    st.title("🔐 Iniciar sesión o registrarse")
    tab1, tab2 = st.tabs(["Iniciar Sesión", "Registrarse"])

    with tab1:
        username = st.text_input("Usuario", key="login_user")
        password = st.text_input("Contraseña", type="password", key="login_pass")
        if st.button("Entrar"):
            if login_user(username, password):
                st.session_state.logged_in = True
                st.session_state.username = username
                st.success("Sesión iniciada correctamente.")
            else:
                st.error("Usuario o contraseña incorrecta.")

    with tab2:
        new_user = st.text_input("Nuevo Usuario", key="new_user")
        new_pass = st.text_input("Nueva Contraseña", type="password", key="new_pass")
        if st.button("Registrarse"):
            if register_user(new_user, new_pass):
                st.success("Usuario creado. Ahora puedes iniciar sesión.")
            else:
                st.error("Ese usuario ya existe.")

def app_section():
    st.title(f"👋 Hola, {st.session_state.username}")
    st.subheader("💳 Calculadora de crédito")

    limit = st.number_input("Límite de tu tarjeta ($)", min_value=0.0)
    balance = st.number_input("Saldo actual ($)", min_value=0.0)

    if limit > 0:
        usage = (balance / limit) * 100
    else:
        usage = 0

    st.markdown(f"**Uso actual del crédito:** {usage:.2f}%")

    if usage > 30:
        st.error("⚠️ Estás usando mucho crédito.")
    else:
        st.success("✅ Buen uso del crédito.")

    st.subheader("🧾 Registrar pago")
    pago = st.number_input("Monto del pago ($)", min_value=0.0)
    if st.button("Guardar pago"):
        if pago > 0:
            save_payment(st.session_state.username, pago)
            st.success(f"Pago de ${pago:.2f} guardado.")

    st.subheader("📈 Historial de pagos")
    pagos = get_user_payments(st.session_state.username)
    if pagos:
        for p in pagos:
            st.write(f"- ${p:.2f}")
    else:
        st.write("No hay pagos registrados.")

    if st.button("Cerrar sesión"):
        st.session_state.logged_in = False
        st.session_state.username = ""

if st.session_state.logged_in:
    app_section()
else:
    login_section()
